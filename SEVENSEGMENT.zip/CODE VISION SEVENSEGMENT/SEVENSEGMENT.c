#include <io.h>
#include <delay.h>
unsigned char sevensegment[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F };
void main(void) 
{
int i;
DDRB = 0x7F;
PORTB = 0x00;
while (1) 
 {
  for(i = 0 ; i < 10 ; i++) 
   {
   PORTB = sevensegment[i];
   delay_ms(500);
   }
 }

}
