#include <stdlib.h>
#include <delay.h>
#include <alcd.h>
void main(void)
{
    int a = 0, i = 0;
    char lcd[16];
    lcd_init(16);
    while (1)
    {
        for (i = 0; i < 10; i++)
        {
            a++;
            itoa(a, lcd);
            lcd_clear();
            lcd_puts(lcd);
            delay_ms(100);
        }
        a = 0;
    };
}
