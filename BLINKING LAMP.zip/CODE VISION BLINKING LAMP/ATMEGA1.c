#include <io.h>
#include <delay.h>
void main(void) {
 DDRB.0 = 1;
 PORTB.0 = 0;
 while(1)
 {
 PORTB.0 = !PORTB.0 ;
 delay_ms(500);
 }
}
