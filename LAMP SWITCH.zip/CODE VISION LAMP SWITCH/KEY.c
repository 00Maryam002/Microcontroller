#include <io.h>
#include <delay.h>
void main(void) {
DDRB.0 = 1 ;
PORTB.0 = 0;
DDRB.7 = 0;
PORTB.7 = 1;
while(1)
{
 while (PINB.7 == 1 )
 {
 PORTB.0 = !PORTB.0 ;
 delay_ms(1000);
 }
}
}
